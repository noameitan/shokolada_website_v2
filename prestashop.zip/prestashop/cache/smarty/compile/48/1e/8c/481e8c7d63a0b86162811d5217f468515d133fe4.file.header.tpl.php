<?php /* Smarty version Smarty-3.1.14, created on 2014-01-19 23:29:50
         compiled from "D:\wamp\www\1561\prestashop\modules\stmegamenu\views\templates\hook\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2030552dc43ce9dbec8-99045450%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '481e8c7d63a0b86162811d5217f468515d133fe4' => 
    array (
      0 => 'D:\\wamp\\www\\1561\\prestashop\\modules\\stmegamenu\\views\\templates\\hook\\header.tpl',
      1 => 1389102184,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2030552dc43ce9dbec8-99045450',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'megamenu_custom_css' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_52dc43cea19c00_69987105',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52dc43cea19c00_69987105')) {function content_52dc43cea19c00_69987105($_smarty_tpl) {?>
<?php if (isset($_smarty_tpl->tpl_vars['megamenu_custom_css']->value)&&$_smarty_tpl->tpl_vars['megamenu_custom_css']->value){?>
<style type="text/css">
<?php echo $_smarty_tpl->tpl_vars['megamenu_custom_css']->value;?>

</style>
<?php }?>
<?php }} ?>