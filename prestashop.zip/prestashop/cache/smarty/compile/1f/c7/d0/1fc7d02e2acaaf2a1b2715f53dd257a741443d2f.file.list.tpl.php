<?php /* Smarty version Smarty-3.1.14, created on 2014-01-15 16:24:17
         compiled from "D:\wamp\www\1561\prestashop\admin8955\themes\default\template\helpers\list\list.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2490752d69a117bdbb5-36992083%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1fc7d02e2acaaf2a1b2715f53dd257a741443d2f' => 
    array (
      0 => 'D:\\wamp\\www\\1561\\prestashop\\admin8955\\themes\\default\\template\\helpers\\list\\list.tpl',
      1 => 1384783796,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2490752d69a117bdbb5-36992083',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'header' => 0,
    'content' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_52d69a117ded73_77039847',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52d69a117ded73_77039847')) {function content_52d69a117ded73_77039847($_smarty_tpl) {?>
<?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>

<?php }} ?>